package com.trait;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpCigma1Application {

	public static void main(String[] args) {
		SpringApplication.run(TpCigma1Application.class, args);
	}

}
